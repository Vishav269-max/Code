"use client"

import { useState } from 'react';
import { GitBranch, BrainCircuit, FileText, Bot, Sparkles, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { generateCode } from '@/ai/flows/generate-code-from-prompt';
import { suggestCodeImprovements } from '@/ai/flows/suggest-code-improvements';
import { generateDocumentationSnippets } from '@/ai/flows/generate-documentation-snippets';
import { useToast } from "@/hooks/use-toast";
import type { GenerateDocumentationSnippetsOutput } from '@/ai/flows/generate-documentation-snippets';
import type { SuggestCodeImprovementsOutput } from '@/ai/flows/suggest-code-improvements';
import { Skeleton } from '../ui/skeleton';

type EditorViewProps = {
  code: string;
  setCode: (code: string) => void;
};

export default function EditorView({ code, setCode }: EditorViewProps) {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [loadingAction, setLoadingAction] = useState<'generate' | 'improve' | 'docs' | null>(null);
    const [aiTab, setAiTab] = useState('assistant');
    const [suggestions, setSuggestions] = useState<SuggestCodeImprovementsOutput['suggestions']>([]);
    const [docs, setDocs] = useState<GenerateDocumentationSnippetsOutput['documentationSnippets'] | null>(null);
    const { toast } = useToast();

    const handleGenerateCode = async () => {
        if (!prompt) return;
        setIsLoading(true);
        setLoadingAction('generate');
        try {
            const result = await generateCode({ prompt });
            setCode(result.code);
        } catch (error) {
            console.error(error);
            toast({
                variant: "destructive",
                title: "Error generating code",
                description: "There was an issue with the AI assistant. Please try again.",
            });
        }
        setIsLoading(false);
        setLoadingAction(null);
    };
    
    const handleImproveCode = async () => {
        setIsLoading(true);
        setLoadingAction('improve');
        setSuggestions([]);
        try {
            const result = await suggestCodeImprovements({ code, language: 'html' });
            setSuggestions(result.suggestions);
            setAiTab('suggestions');
        } catch (error) {
            console.error(error);
            toast({
                variant: "destructive",
                title: "Error improving code",
                description: "There was an issue fetching suggestions. Please try again.",
            });
        }
        setIsLoading(false);
        setLoadingAction(null);
    };

    const handleGetDocs = async () => {
        setIsLoading(true);
        setLoadingAction('docs');
        setDocs(null);
        try {
            const result = await generateDocumentationSnippets({ codeSnippet: code, programmingLanguage: 'html' });
            setDocs(result.documentationSnippets);
            setAiTab('docs');
        } catch (error) {
            console.error(error);
            toast({
                variant: "destructive",
                title: "Error fetching docs",
                description: "There was an issue fetching documentation. Please try again.",
            });
        }
        setIsLoading(false);
        setLoadingAction(null);
    };

  return (
    <div className="flex flex-col h-full bg-background/70">
        <div className="flex items-center justify-between p-2 border-b border-border">
            <div className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-muted-foreground" />
                <Select defaultValue="main">
                    <SelectTrigger className="h-8 text-sm focus:ring-0 border-none bg-transparent">
                        <SelectValue placeholder="Branch" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="main">main</SelectItem>
                        <SelectItem value="develop">develop</SelectItem>
                        <SelectItem value="feature/new-ui">feature/new-ui</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div className="flex items-center gap-2">
                 <Button variant="outline" size="sm" onClick={handleImproveCode} disabled={isLoading}>
                    <Sparkles className={`w-4 h-4 mr-2 ${loadingAction === 'improve' && 'animate-spin'}`} /> Improve
                 </Button>
                 <Button variant="outline" size="sm" onClick={handleGetDocs} disabled={isLoading}>
                    <FileText className={`w-4 h-4 mr-2 ${loadingAction === 'docs' && 'animate-spin'}`} /> Get Docs
                 </Button>
            </div>
        </div>
        <div className="flex-1 flex flex-col min-h-0">
             <Textarea
                placeholder="Your code goes here..."
                className="w-full flex-1 p-4 bg-transparent border-0 rounded-none resize-none focus-visible:ring-0 font-code text-sm leading-relaxed"
                value={code}
                onChange={(e) => setCode(e.target.value)}
            />
            <div className="border-t border-border bg-background">
                <Tabs value={aiTab} onValueChange={setAiTab} className="p-2">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="assistant"><BrainCircuit className="w-4 h-4 mr-2" />AI Assistant</TabsTrigger>
                        <TabsTrigger value="suggestions" disabled={suggestions.length === 0 && !isLoading}>
                          <Sparkles className="w-4 h-4 mr-2" />Suggestions
                        </TabsTrigger>
                        <TabsTrigger value="docs" disabled={!docs && !isLoading}>
                          <FileText className="w-4 h-4 mr-2" />Docs
                        </TabsTrigger>
                    </TabsList>
                    <TabsContent value="assistant" className="mt-2">
                        <div className="relative">
                        <Textarea
                            placeholder="Describe the code you want to generate..."
                            className="w-full p-4 pr-28 bg-muted/50 border rounded-md resize-none font-code text-xs"
                            rows={3}
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                        />
                        <Button size="sm" className="absolute right-3 top-3" onClick={handleGenerateCode} disabled={isLoading || !prompt}>
                            {loadingAction === 'generate' ? 'Generating...' : <>Generate <Sparkles className="w-4 h-4 ml-2" /></>}
                        </Button>
                        </div>
                    </TabsContent>
                    <TabsContent value="suggestions" className="mt-2">
                        <ScrollArea className="h-32">
                            <div className="p-4 bg-muted/50 rounded-md min-h-[8rem]">
                            {loadingAction === 'improve' && (
                                <div className="space-y-2">
                                    <Skeleton className="h-4 w-3/4" />
                                    <Skeleton className="h-4 w-1/2" />
                                </div>
                            )}
                            {!isLoading && suggestions.length === 0 && <div className="flex items-center justify-center h-full text-sm text-muted-foreground"><Bot className="w-5 h-5 mr-2" />Click "Improve" to get AI suggestions.</div>}
                            <ul className="space-y-3">
                                {suggestions.map((s, i) => (
                                    <li key={i} className="flex items-start gap-3 text-sm">
                                        <AlertCircle className="w-5 h-5 mt-0.5 text-accent shrink-0"/>
                                        <span className="font-code">{s}</span>
                                    </li>
                                ))}
                            </ul>
                            </div>
                        </ScrollArea>
                    </TabsContent>
                    <TabsContent value="docs" className="mt-2">
                        <ScrollArea className="h-32">
                           <div className="p-4 bg-muted/50 rounded-md min-h-[8rem]">
                            {loadingAction === 'docs' && (
                                <div className="space-y-2">
                                    <Skeleton className="h-4 w-3/4" />
                                    <Skeleton className="h-4 w-full" />
                                    <Skeleton className="h-4 w-1/2" />
                                </div>
                            )}
                            {!isLoading && !docs && <div className="flex items-center justify-center h-full text-sm text-muted-foreground"><Bot className="w-5 h-5 mr-2" />Click "Get Docs" for relevant documentation.</div>}
                             {docs && <pre className="whitespace-pre-wrap font-code text-xs">{docs}</pre>}
                           </div>
                        </ScrollArea>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    </div>
  );
}
