import { GitBranch, CheckCircle2 } from 'lucide-react';

export default function StatusBar() {
  return (
    <footer className="flex items-center justify-between h-8 px-4 border-t border-border text-xs text-muted-foreground shrink-0 bg-background">
      <div className="flex items-center gap-2">
        <GitBranch className="w-3.5 h-3.5" />
        <span>main</span>
      </div>
      <div className="flex items-center gap-2">
        <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
        <span>Saved</span>
      </div>
    </footer>
  );
}
