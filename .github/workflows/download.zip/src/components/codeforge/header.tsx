"use client"

import { Cpu, Share2, Rocket, Bell, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Separator } from '../ui/separator';

export default function Header() {
  return (
    <header className="flex items-center justify-between h-16 px-4 md:px-6 shrink-0 bg-background">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-lg font-semibold">
          <Cpu className="w-6 h-6 text-primary" />
          <span className="font-headline">CodeForge</span>
        </div>
        <Separator orientation='vertical' className="h-6 hidden md:block" />
        <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
          <span>my-awesome-project</span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex -space-x-2">
          <Avatar className="border-2 border-background h-8 w-8">
            <AvatarImage src="https://placehold.co/40x40.png" data-ai-hint="woman smiling" />
            <AvatarFallback>U1</AvatarFallback>
          </Avatar>
          <Avatar className="border-2 border-background h-8 w-8">
            <AvatarImage src="https://placehold.co/40x40.png" data-ai-hint="man portrait" />
            <AvatarFallback>U2</AvatarFallback>
          </Avatar>
          <Avatar className="border-2 border-background h-8 w-8">
            <AvatarFallback>+3</AvatarFallback>
          </Avatar>
        </div>
        <Button variant="outline" size="sm">
          <Share2 className="w-4 h-4 mr-2" />
          Share
        </Button>
        <Button size="sm" className="bg-primary hover:bg-primary/90">
          <Rocket className="w-4 h-4 mr-2" />
          Deploy
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full">
          <Bell className="w-5 h-5" />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2 rounded-full p-0.5 h-auto">
              <Avatar className="w-8 h-8">
                <AvatarImage src="https://placehold.co/40x40.png" data-ai-hint="man glasses" />
                <AvatarFallback>ME</AvatarFallback>
              </Avatar>
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuItem>Support</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
