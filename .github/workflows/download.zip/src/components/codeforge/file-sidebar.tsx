"use client"

import { useState } from 'react';
import { Folder, FileCode, FileJson, FileImage, Settings, ChevronRight } from 'lucide-react';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from '../ui/button';

const fileSystem = [
  { 
    name: 'src', 
    icon: Folder, 
    children: [
      { 
        name: 'app', 
        icon: Folder, 
        children: [
          { name: 'page.tsx', icon: FileCode, active: true },
          { name: 'layout.tsx', icon: FileCode },
          { name: 'globals.css', icon: FileCode },
        ]
      },
      { 
        name: 'components', 
        icon: Folder, 
        children: [
            { name: 'ui', icon: Folder },
            { name: 'codeforge', icon: Folder },
        ]
      },
    ]
  },
  { name: 'public', icon: Folder, children: [
    { name: 'favicon.ico', icon: FileImage },
  ]},
  { name: 'package.json', icon: FileJson },
  { name: 'tailwind.config.ts', icon: FileCode },
];

function FileEntry({ item, level }: { item: any, level: number }) {
  const [isOpen, setIsOpen] = useState(item.name === 'src' || item.name === 'app');
  const hasChildren = item.children && item.children.length > 0;

  return (
    <div>
      <button
        onClick={() => hasChildren && setIsOpen(!isOpen)}
        className={`w-full flex items-center gap-2 px-2 py-1.5 text-sm rounded-md transition-colors group ${
          item.active ? 'bg-accent text-accent-foreground' : 'hover:bg-muted/50 text-muted-foreground hover:text-foreground'
        }`}
        style={{ paddingLeft: `${0.5 + level * 0.75}rem` }}
      >
        {hasChildren ? (
          <ChevronRight className={`w-4 h-4 transition-transform shrink-0 ${isOpen ? 'rotate-90' : ''}`} />
        ) : (
          <span className="w-4 h-4 shrink-0" />
        )}
        <item.icon className={`w-4 h-4 shrink-0 ${item.active ? 'text-accent-foreground' : ''}`} />
        <span className="truncate">{item.name}</span>
      </button>
      {isOpen && hasChildren && (
        <div className="mt-1 space-y-1">
          {item.children.map((child: any, i: number) => (
            <FileEntry key={i} item={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function FileSidebar() {
  return (
    <aside className="w-64 bg-background flex flex-col shrink-0">
      <div className="p-2 border-b border-border">
        <h2 className="px-2 text-lg font-semibold tracking-tight">CodeForge</h2>
      </div>
      <ScrollArea className="flex-1 px-2 py-4">
        <div className="space-y-1">
          {fileSystem.map((item, index) => (
            <FileEntry key={index} item={item} level={0} />
          ))}
        </div>
      </ScrollArea>
      <div className="p-2 border-t border-border">
        <Button variant="ghost" className="w-full justify-start">
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </div>
    </aside>
  );
}
