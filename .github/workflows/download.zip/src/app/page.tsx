"use client";

import { useState, useEffect } from "react";
import Header from "@/components/codeforge/header";
import FileSidebar from "@/components/codeforge/file-sidebar";
import EditorView from "@/components/codeforge/editor-view";
import PreviewView from "@/components/codeforge/preview-view";
import StatusBar from "@/components/codeforge/status-bar";

const initialCode = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Awesome Site</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f2f5;
            color: #1c1e21;
            transition: background-color 0.3s, color 0.3s;
        }
        .container {
            text-align: center;
            padding: 2rem 4rem;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 2.5rem;
            color: #3F51B5;
        }
        p {
            color: #555;
            font-size: 1.1rem;
        }
        button {
            margin-top: 1rem;
            padding: 10px 20px;
            border: none;
            background-color: #00BCD4;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0097a7;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to CodeForge!</h1>
        <p>Edit this code to see the live preview update.</p>
        <button id="theme-toggle">Toggle Dark Mode</button>
    </div>

    <script>
        document.getElementById('theme-toggle').addEventListener('click', () => {
            document.body.style.backgroundColor = document.body.style.backgroundColor === 'rgb(33, 33, 33)' ? '#f0f2f5' : '#212121';
            document.body.style.color = document.body.style.color === 'rgb(250, 250, 250)' ? '#1c1e21' : '#fafafa';
        });
    </script>
</body>
</html>`;

export default function CodeForgePage() {
  const [code, setCode] = useState(initialCode);
  const [srcDoc, setSrcDoc] = useState("");

  useEffect(() => {
    const timeout = setTimeout(() => {
      setSrcDoc(code);
    }, 250);
    return () => clearTimeout(timeout);
  }, [code]);

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      <Header />
      <div className="flex flex-1 min-h-0 border-t border-border">
        <FileSidebar />
        <main className="flex-1 flex flex-col min-w-0 border-l border-border">
          <div className="flex-1 grid grid-cols-[1fr_auto_1fr] min-w-0">
            <div className="min-w-0 flex flex-col">
              <EditorView code={code} setCode={setCode} />
            </div>

            <div className="w-1.5 cursor-col-resize bg-border hover:bg-accent/50 transition-colors flex items-center justify-center group">
                <div className="h-10 w-px bg-muted-foreground/30 group-hover:bg-accent-foreground/50" />
            </div>

            <div className="min-w-0 flex flex-col">
              <PreviewView srcDoc={srcDoc} />
            </div>
          </div>
          <StatusBar />
        </main>
      </div>
    </div>
  );
}
