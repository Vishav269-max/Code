'use server';

/**
 * @fileOverview An AI agent that incorporates relevant documentation snippets when providing code suggestions.
 *
 * - generateDocumentationSnippets - A function that generates documentation snippets for code suggestions.
 * - GenerateDocumentationSnippetsInput - The input type for the generateDocumentationSnippets function.
 * - GenerateDocumentationSnippetsOutput - The return type for the generateDocumentationSnippets function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateDocumentationSnippetsInputSchema = z.object({
  codeSnippet: z
    .string()
    .describe('The code snippet to generate documentation snippets for.'),
  programmingLanguage: z
    .string()
    .describe('The programming language of the code snippet.'),
});
export type GenerateDocumentationSnippetsInput = z.infer<
  typeof GenerateDocumentationSnippetsInputSchema
>;

const GenerateDocumentationSnippetsOutputSchema = z.object({
  documentationSnippets: z
    .string()
    .describe(
      'The documentation snippets for the code snippet, providing context and usage.'
    ),
});
export type GenerateDocumentationSnippetsOutput = z.infer<
  typeof GenerateDocumentationSnippetsOutputSchema
>;

export async function generateDocumentationSnippets(
  input: GenerateDocumentationSnippetsInput
): Promise<GenerateDocumentationSnippetsOutput> {
  return generateDocumentationSnippetsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateDocumentationSnippetsPrompt',
  input: {schema: GenerateDocumentationSnippetsInputSchema},
  output: {schema: GenerateDocumentationSnippetsOutputSchema},
  prompt: `You are an AI code assistant that provides documentation snippets for code suggestions.

  Given the following code snippet and programming language, generate relevant documentation snippets to help the developer understand the context and usage of the code.

  Programming Language: {{{programmingLanguage}}}
  Code Snippet: {{{codeSnippet}}}

  Documentation Snippets:`,
});

const generateDocumentationSnippetsFlow = ai.defineFlow(
  {
    name: 'generateDocumentationSnippetsFlow',
    inputSchema: GenerateDocumentationSnippetsInputSchema,
    outputSchema: GenerateDocumentationSnippetsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
